import streamlit as st
from PyPDF2 import PdfReader
import openai
import os

openai.api_key = os.getenv("OPENAI_API_KEY")

st.title("📄 AI Text Summarizer")

text = st.text_area("Paste your text")

pdf = st.file_uploader("Upload PDF", type="pdf")

if pdf:
    reader = PdfReader(pdf)
    text = ""
    for page in reader.pages:
        text += page.extract_text()

length = st.selectbox("Summary Length", ["Short", "Medium", "Detailed"])

if st.button("Summarize"):
    prompt = f"Summarize this in {length} form:\n{text}"
    response = openai.ChatCompletion.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}]
    )
    st.write(response['choices'][0]['message']['content'])
