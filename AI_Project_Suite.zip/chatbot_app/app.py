import streamlit as st
import google.generativeai as genai
import os
from dotenv import load_dotenv

load_dotenv()
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))

model = genai.GenerativeModel("gemini-pro")

st.title("🤖 AI Chatbot (Gemini)")

if "chat" not in st.session_state:
    st.session_state.chat = model.start_chat(history=[])

user_input = st.text_input("Ask something:")

if user_input:
    response = st.session_state.chat.send_message(user_input)
    st.write("🧠 AI:", response.text)

if st.button("Reset Chat"):
    st.session_state.chat = model.start_chat(history=[])
