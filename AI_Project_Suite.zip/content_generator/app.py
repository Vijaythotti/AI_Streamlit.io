import streamlit as st
import openai
import os

openai.api_key = os.getenv("OPENAI_API_KEY")

st.title("✍️ AI Content Generator")

topic = st.text_input("Enter Topic")
tone = st.selectbox("Tone", ["Formal", "Casual", "Creative"])
format_type = st.selectbox("Format", ["Blog", "LinkedIn", "Twitter"])

if st.button("Generate"):
    prompt = f"Write a {tone} {format_type} on {topic}"

    response = openai.ChatCompletion.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}]
    )

    st.write(response['choices'][0]['message']['content'])
