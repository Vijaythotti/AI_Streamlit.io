import streamlit as st
import openai
import os

openai.api_key = os.getenv("OPENAI_API_KEY")

st.title("💻 Code Explainer")

code = st.text_area("Paste your code")
level = st.selectbox("Level", ["Beginner", "Advanced"])

if st.button("Explain"):
    prompt = f"Explain this code in {level} level:\n{code}"

    response = openai.ChatCompletion.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}]
    )

    st.write(response['choices'][0]['message']['content'])
