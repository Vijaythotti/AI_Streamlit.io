import streamlit as st
from PyPDF2 import PdfReader
import openai
import os

openai.api_key = os.getenv("OPENAI_API_KEY")

st.title("📊 AI Resume Analyzer")

resume = st.file_uploader("Upload Resume (PDF)", type="pdf")
job_desc = st.text_area("Paste Job Description")

if resume and job_desc:
    reader = PdfReader(resume)
    text = ""
    for page in reader.pages:
        text += page.extract_text()

    prompt = f"""
    Compare resume and job description.
    Give:
    1. Match %
    2. Missing skills
    3. Improvements

    Resume:
    {text}

    Job Description:
    {job_desc}
    """

    if st.button("Analyze"):
        response = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}]
        )
        st.write(response['choices'][0]['message']['content'])
